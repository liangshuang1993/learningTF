import tensorflow as tf

a = tf.Variable(1.0, name="variable_a")
b = tf.Variable(2.0)
c = tf.add(a, b)

init = tf.global_variables_initializer()
sess = tf.Session()

sess.run(init)

print tf.trainable_variables()